#ifndef COMPRESSOR_H
#define COMPRESSOR_H

#include <string>

std::string compressRLE(const std::string& data);
void compressInParallel(const std::string& input, int numThreads, std::string& output);
std::string decompressRLE(const std::string& data);

#endif