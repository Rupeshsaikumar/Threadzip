#include <iostream>
#include <fstream>
#include <chrono>
#include "compressor.h"

int main() {
    std::ifstream inFile("testfile.txt", std::ios::binary);
    std::string input((std::istreambuf_iterator<char>(inFile)), std::istreambuf_iterator<char>());
    inFile.close();

    std::string compressed, decompressed;

    // Single-threaded compression
    auto start = std::chrono::high_resolution_clock::now();
    compressed = compressRLE(input);
    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "Single-threaded compression time: " << std::chrono::duration<double>(end - start).count() << "s\n";

    // Multi-threaded compression
    std::string threadedCompressed;
    start = std::chrono::high_resolution_clock::now();
    compressInParallel(input, 4, threadedCompressed);
    end = std::chrono::high_resolution_clock::now();
    std::cout << "Multi-threaded compression time: " << std::chrono::duration<double>(end - start).count() << "s\n";

    // Save compressed file
    std::ofstream out("output/compressed.cmp", std::ios::binary);
    out << threadedCompressed;
    out.close();

    // Decompress
    decompressed = decompressRLE(threadedCompressed);
    std::ofstream out2("output/decompressed.txt", std::ios::binary);
    out2 << decompressed;
    out2.close();

    std::cout << "Decompression complete.\n";

    return 0;
}